const db = require("../util/sqlDatabase.js");

module.exports = class Users {
  constructor(username, password) {
    this.username = username;
    this.password = password;
  }
  async save() {
    return await db.execute(
      "INSERT INTO users(username,password)VALUES (?,?)",
      [this.username, this.password]
    );
    //we return a promise which contain in mysql2 two things
    //1.row(result data)
    //2.filds(what is table made of like)
    /*
        [
         `username` VARCHAR(50) NOT NULL PRIMARY KEY UNIQUE_KEY,
         `email` VARCHAR(255),
         `password` VARCHAR(255) NOT NULL
        ]
    const [rows, fields] which are itself arrays of objects and strings respectively
    //we getting two element array in which element are array itself
    */
    //sql injection k liye ??(question mark use)
  }
  static async findUser(username) {
    return await db.execute("SELECT * FROM users where username=?", [username]);
  }
  static deleteByUsername(username) {
    //username; delete account later...
  }
  static async fetchAllUsers() {
    return await db.execute("SELECT * FROM users");
    //returns all users present in our database..+ passwords also returning
    //don't return password
  }
  static async fetchAllFriends(username) {
    return await db.execute("SELECT * FROM friends where username=?", [
      username,
    ]);
  }
  static async incomingRequests(username) {
    return await db.execute(
      "SELECT * FROM pendingrequests where recieverUsername=?",
      [username]
    );
  }
  static async addToFriend(senderUsername, recieverUsername) {
    //already friend nhi honge otherwise pending req m nhi hoti
    try {
      const [result] = await db.execute(
        "DELETE FROM pendingrequests WHERE recieverUsername=? AND senderUsername=?",
        [recieverUsername, senderUsername]
      );
      if (result.affectedRows === 0) {
        return false;
      }
      //result.afected rows shoudl be one then,
      //add both on each other
      const [result2] = await db.execute(
        "INSERT INTO friends(username,friendsUsername) VALUES (?,?)",
        [senderUsername, recieverUsername]
      );
      if (result2.affectedRows === 0) {
        return false;
      }
      //check affeted rows should be one
      const [result3] = await db.execute(
        "INSERT INTO friends(username,friendsUsername) VALUES(?,?)",
        [recieverUsername, senderUsername]
      );
      if (result3.affectedRows === 0) {
        return false;
        //also alter result 2 back jaisa tha vaise kr do
      }
      return true;
    } catch (err) {
      throw new Error("errror ....function addToFriend");
    }
  }
  static async delelteFromPendingRequest(senderUsername, receiverUsername) {
    try {
      const [result] = await db.execute(
        "DELETE FROM pendingrequests WHERE recieverUsername=? AND senderUsername=?",
        [receiverUsername, senderUsername]
      );
      if (result.affectedRows === 1) {
        return true;
      } else {
        return false;
      }
    } catch (err) {
      throw new Error("not delted");
    }
  }
  static async mutualFriends(username1, username2) {
    //friends table m JOIN use or dono users k friends store in
    //two arrays and then find common using set or anything..
  }
  /*
  static findByUsername(username) {
    return db.execute("SELECT * FROM users WHERE users.username=?", [username]);
  }
    */
  static async login(username, password) {
    return await db.execute(
      "SELECT * FROM users WHERE username=? AND password = ?",
      [username, password]
    );
  }
  static async findByEmail(email) {
    return await db.execute("SELECT * FROM users WHERE users.email=?", [email]);
  }
  static async usernameExist(username) {
    return db.execute("SELECT * FROM users WHERE username=?", [username]);
  }
  static async allPendingRequestSendByUser(username) {
    return await db.execute(
      "SELECT * FROM pendingrequests WHERE senderUsername=?",
      [username]
    );
  }
  static async handleWithdrawRequest(sender, reciever) {
    return db.execute(
      "DELETE FROM pendingrequests WHERE recieverUsername = ? AND senderUsername = ?",
      [reciever, sender]
    );
  }
  static async sendRequest(senderUsername, receiverUsername) {
    //add to pending friends if already not in pending friends.
    //check alrready exist or not?
    //first check reciver username is exist or not??

    try {
      // Check if receiver exists
      const [receiverRows] = await db.execute(
        "SELECT * FROM users WHERE username = ?",
        [receiverUsername]
      );

      if (receiverRows.length === 0) {
        return { success: false, message: "Receiver does not exist" };
      }

      // Check if already friends
      const [friendRows] = await db.execute(
        "SELECT * FROM friends WHERE username = ? AND friendsUsername = ?",
        [receiverUsername, senderUsername]
      );

      if (friendRows.length > 0) {
        return { success: false, message: "Already friends" };
      }

      // Check if request already sent
      const [pendingRows] = await db.execute(
        "SELECT * FROM pendingrequests WHERE recieverUsername = ? AND senderUsername = ?",
        [receiverUsername, senderUsername]
      );

      if (pendingRows.length > 0) {
        return { success: false, message: "Request already sent" };
      }

      // Send the friend request
      const [result] = await db.execute(
        "INSERT INTO pendingrequests (recieverUsername, senderUsername) VALUES (?, ?)",
        [receiverUsername, senderUsername]
      );
      if (result.affectedRows === 1) {
        console.log("insertion successfull");
        return { success: true, message: "Request sent successfully" };
      }
      console.log("some unknow sql error:");
      return { success: false, message: "SQL error" };
    } catch (err) {
      console.error("Error in sendRequest:", err);
      return { success: false, message: "Internal server error" };
    }
  }
  static async showFriends(username) {
    try {
      console.log("starting to fetch");
      const [result] = await db.execute(
        "SELECT * FROM friends where username=?",
        [username]
      );
      console.log(result);
      return result;
    } catch (err) {
      console.log("error in fetching friends");
    }
  }
  static acceptRequest(username, friendUsername) {
    //delte from pending friends
    //and add to friends only if already not friends
  }
  static deleteFriend(username, friendUsernameToDelelte) {
    //check if friend then only delte..
    //first check friend exist??
    return db.execute(
      "DELETE FROM friends WHERE username=? AND friendsUsername =?",
      [username, friendsUsername]
    );
  }
};

/*db.execute("SELECT * FROM users WHERE users.username=?", [recieverUsername])
      .then(([rows]) => {
        if (rows.length === 0) {
          console.log("user not found");
          return { success: false, message: "user does not exist" };
        }
        //now check, if request present or not? already
        //friends already or not??
        db.execute(
          "SELECT * FROM friends WHERE friends.username=? AND friends.friendsUsername=?",
          [recieverUsername, senderUsername]
        )
          .then(([rows]) => {
            if (rows.length === 1) {
              console.log("already friend");
              return { success: false, message: "user already friend" };
            }
          })
          .catch((err) => {
            console.log("error while finding friend");
          });
      })
      .catch((err) => {
        console.log(
          "doesn't exist the user which you are trying to send Request"
        );
        return;
      });
      */

//now, we can create Users in some file then obj.save() will save username and password
//object that is calling will have the username
//second table username(currentuser) and its friends_name
//then join both table..
//combine username and friends_name should be unique.
