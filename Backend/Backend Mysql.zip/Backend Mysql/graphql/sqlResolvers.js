//const { addFriend, mutualFriends } = require("../controllers/user");
/*
2. Token authentication: backend or frontend?
Backend issues the token after validating credentials (like we did in your validateUser).

Frontend receives the token and stores it (usually in localStorage or sessionStorage).

For future requests (queries/mutations), frontend sends the token in the Authorization header.

Backend verifies the token for every request needing authentication to identify the user.

type AuthData {
  success: Boolean!
  token: String
  message: String
}

type Mutation {
  loginUser(username: String!, password: String!): AuthData!
}

*/
const User = require("../models/sqlCreateUser");
//const Friends = require("../models/sqlFriendsTable.js");
//const PendingFriendRequests = rquire("../models/sqlPendingFriendRequests");
function validName(name) {
  /*
        these already checked in frontend by react..
    */
}
const jwt = require("jsonwebtoken");
const JWT_SECRET = "secretsuperstar";
//LOGIN USERNAME AND PASSWORD VALIDATION CHECK IN FRONTEND THEN SEND REQUEST HERE VIA GRAPHQL
module.exports = {
  /*
    hello(){
        return 'hello World';
    }
        */
  /*
  hello() {
    return {
      text: "hello",
      views: 1234,
    };
  },
  */
  handleWithdrawRequest: async function ({ sender, reciever }, req) {
    try {
      console.log("sender is: " + sender + " reciever is: " + reciever);
      const [result] = await User.handleWithdrawRequest(sender, reciever);
      if (result.affectedRows > 0) {
        return true;
      } else {
        return false;
      }
    } catch (err) {
      console.error("DB Error:", err);
      throw new Error("Something went wrong");
    }
  },
  addToFriends: async function ({ username, friendsUsername }, req) {
    try {
      const result = await User.addToFriend(username, friendsUsername);
      if (result) {
        return true;
      }
      return false;
    } catch (err) {
      throw new Error("error");
    }
  },
  delelteFromPendingRequests: async function (
    { username, friendsUsername },
    req
  ) {
    try {
      const result = await User.delelteFromPendingRequest(
        username,
        friendsUsername
      );
      if (result) {
        return true;
      } else {
        return false;
      }
    } catch (err) {
      throw new Error("error");
    }
  },
  incomingRequests: async function ({ username }, req) {
    try {
      const [result] = await User.incomingRequests(username);
      const senderUsername = [];
      result.forEach((val) => {
        senderUsername.push(val.senderUsername);
      });
      return {
        friends: senderUsername,
        message: "success",
        success: true,
      };
    } catch (err) {
      throw new Error("error on checking incoming requests on user");
    }
  },
  showAllUsers: async function ({}, req) {
    try {
      const [result] = await User.fetchAllUsers();
      const users = [];
      result.forEach((val) => {
        users.push(val.username);
      });
      return users;
    } catch (err) {
      throw new Error("error while fetching user");
    }
  },
  showAllFriends: async function ({ username }, req) {
    try {
      /*
for this schema: 
 showAllFriends(username:String!):friendsArray
    type friendsArray{
        friends:[String],
        message:String,
        success:Boolean
    }return this..

    */
      if (!req.isAuth) {
        //not authenticated request so no add friend
        throw new Error("Unauthenticated!");
      }
      const [result] = await User.fetchAllFriends(username);
      const ans = [];
      result.forEach((val) => {
        ans.push(val.friendsUsername);
      });
      if (result.length > 0) {
        return {
          friends: ans,
          message: "success",
          success: true,
        };
      } else {
        return {
          friends: ans,
          message: "No Friends",
          success: false,
        };
      }
    } catch (err) {
      throw new Error("error showing all friends");
    }
  },
  createUser: async function ({ username, password }, req) {
    try {
      //we have made the user input//
      //USER VALIDATION TOH REACT KRKE REQUEST BHEJEGA
      //functions recieves the argument that are define in schema
      //const userName = userInput.name;
      //const temp = userInput.friends;
      //const userFriends = temp.split(/\s*,\s*/);
      //check username already exist or not?
      const [exist] = await User.findUser(username);
      if (exist.length !== 0) {
        //already exist
        return {
          success: false,
          token: "",
          message: "Username already Exist",
        };
      }
      const obj = new User(username, password);
      //obj.save(); //this will save in database
      const [result, metaData] = await obj.save();
      //result will contain the rows that are returned from the query
      //result will contain array of object coln: value
      if (result.affectedRows === 1) {
        console.log("user inserted successfully");
        //otherwise not successfull m catch m chale jayega
        //INSERT QUERY didn't return anything..
        //token is string only..
        const token = jwt.sign(
          {
            username: username,
            // you can add more user info here if needed
          },
          JWT_SECRET,
          { expiresIn: "1h" } // token expires in 1 hour
        );
        return {
          success: true,
          token: token,
          message: "insertion successfull",
        };
      }
      //if somehow insertion failed silently
      return {
        success: false,
        token: "",
        message: "Some insertion failed silently",
      };
      //if save() failed means, not inserted in tabel because of duplicate key or
      //invalid query and it will go to catch because we using async and await
      //if promise so then() ki jagah catch() m chale jata
      /*
      const user = new User({
        name: userName,
      });
      const result = await user.save();
      const objCreated = await User.findById(result._id);
      //result and objCreated are same
      for (const friend of userFriends) {
        try {
          console.log("Trying to add friend with id: ", friend.trim());
          const friendId = friend.trim();
          //find the friend by Id
          if (!mongoose.Types.ObjectId.isValid(friend)) {
            console.log("invalid objectId type mongoose");
            const error = new Error("Invalid user ID to add.");
            error.statusCode = 400;
            throw error;
          }
          console.log("Before findbyId");
          const exist = await User.findById(friendId);
          console.log("After  Find by Id");
          if (exist) {
            console.log("this id exists: ", exist._id);
            exist.friends.push(objCreated._id);
            objCreated.friends.push(exist._id);
            const notneeded = await exist.save();
          } else {
            console.log("Friend with id ", friend, " doesn't exist");
          }
        } catch (err) {
          console.log("Error processing friend with id ", friend, err);
        }
      }
      const updatedUser = await objCreated.save();
      return updatedUser; //same schema h inka
      */
    } catch (err) {
      console.log("error in creating User");
      console.log(err);
      return {
        success: false,
        token: "",
        message: "error in inserting in sql table maybe duplicate entry",
      }; //returning false means, request not executed..
    }
  },
  loginUser: async function ({ username, password }, req) {
    try {
      console.log("logging trying");
      const [result, field] = await User.login(username, password);
      console.log(result);
      console.log("loging trying:");
      if (result.length === 0) {
        //return not found
        console.log("user not found");
        return {
          successs: false,
          token: "",
          message: "Invalid username or password",
        };
      }
      if (result.length === 1) {
        const token = jwt.sign(
          {
            username: username,

            // you can add more user info here if needed
          },
          JWT_SECRET,
          { expiresIn: "1h" } // token expires in 1 hour
        );
        console.log("user found succesfull login:");
        return {
          success: true,
          token: token,
          message: "Login successfull!!",
        };
      }
      return {
        success: false,
        token: "",
        message: "maybe more than 1 result(entry)",
      };
    } catch (err) {
      console.log("error");
      return {
        success: false,
        token: "",
        message:
          "error in accessing database query or invalid username or password",
      };
    }
  },
  allPendingRequestSendByUser: async function ({ username }, req) {
    try {
      /*
      if (!req.isAuth) {
        console.log("unauthenticated request");
        throw new Error("unauthenticated");
      }
        */
      const friends = [];
      const [result] = await User.allPendingRequestSendByUser(username);
      if (result.length === 0) {
        console.log("no req send");
      }
      result.forEach((val) => {
        friends.push(val.recieverUsername);
      });
      return {
        friends: friends,
        message: "fetched request send by this user",
        success: true,
      };
    } catch (err) {
      console.log("error in fetching pending friends");
      throw new Error("error in fetching friends");
    }
  },
  addFriend: async function ({ curr_user_id, friend_user_id }, req) {
    try {
      /*
      if (!req.isAuth) {
        //not authenticated request so no add friend
        throw new Error("Unauthenticated!");
      }
        */
      const result = await User.sendRequest(curr_user_id, friend_user_id);
      if (result.success === true) {
        //_id: updatedUser._id, (NO ID)
        return "success";
      }
      return "failure";
    } catch (err) {
      // Error handling
      console.log(err);
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      //next(err); // Passing the error to the global error handler
    }
  },
  showFriends: async function ({ curr_user_id }, req) {
    try {
      /*
      if (!req.isAuth) {
        //not authenticated request so no add friend
        throw new Error("Unauthenticated!");
      }
        */
      const ans = [];
      const result = await User.showFriends(curr_user_id);
      result.forEach((values) => {
        //pushing friends username
        ans.push(values.friendsUsername);
      });
      //check friendsUsername or friendsusername in small
      return ans;
    } catch (err) {
      // Error handling
      console.log("error in request");
      console.log(err);
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      //next(err); // Passing the error to the global error handler
    }
  },
  mutualFriends: async function ({ curr_user_id, friend_user_id }, req) {
    //here we get current user Id and id of the user we want to find mutual friends of
    try {
      /*
        type mutualFriend{
        friends:[String],
        message:String,
        Success:bool
        }
        RETURN STRUCTURE
        */
      const ans1 = [];
      const ans2 = [];
      const [firstExist, metaData] = await User.usernameExist(curr_user_id);
      //first object array and then second metaData
      if (firstExist.length === 0) {
        console.log("First Username doesn't exist");
        return {
          friends: [],
          message: "Friends user not exist",
          success: false,
        };
      }
      const result1 = await User.showFriends(curr_user_id);
      //for friend user Id, first check exist or not
      const [result2] = await User.usernameExist(friend_user_id);
      if (result2.length === 0) {
        console.log("Friend user not exist");
        return {
          friends: [],
          message: "Friend user not exist",
          success: false,
        };
      }
      const result3 = await User.showFriends(friend_user_id);
      result3.forEach((val) => {
        if (
          val.friendsUsername !== curr_user_id &&
          val.friendsUsername !== friend_user_id
        ) {
          ans2.push(val.friendsUsername);
        }
      });
      result1.forEach((val) => {
        if (
          val.friendsUsername !== curr_user_id &&
          val.friendsUsername !== friend_user_id
        ) {
          ans1.push(val.friendsUsername);
        }
      });
      const set = new Set();
      ans1.forEach((val) => {
        set.add(val);
      });
      const ans = [];
      ans2.forEach((val) => {
        if (set.has(val)) {
          ans.push(val);
        }
      });
      return {
        friends: ans,
        message: "successfull",
        success: true,
      };
    } catch (err) {
      // Error handling
      console.log(err);
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      throw new Error("error in getting mutual friends");
      //next(err); // Passing the error to the global error handler
    }
  },
  showAllDocument: async function (args, req) {
    // '/' route starting m, this function call
    //addFriend agar call hoga toh, re-render kra linge..
    try {
      const [result] = await User.fetchAllUsers();
      const ans = [];
      result.forEach((val) => {
        ans.push(val.username);
      });
      return ans;
    } catch (err) {
      console.log("document not find");
      console.log(err);
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      //next(err);
    }
  },
  userDetail: async function ({ curr_user_id }, req) {
    try {
    } catch (err) {
      console.log("document not find");
      console.log(err);
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      //next(err);
    }
  },
  deleteUser: async function ({ curr_user_id }, req) {
    try {
      //check authentication
    } catch (err) {
      console.log("user not found");
      console.log(err);
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      //next(err);
    }
  },
  deleteFriend: async function ({ curr_user_id, friend_user_id }, req) {
    try {
      //first check friend exist or not ..
    } catch (err) {
      console.log("friend not found");
      console.log(err);
      if (!err.statusCode) {
        err.statusCode = 500;
      }
      //next(err);
      return "false";
      //next(err);
    }
    //where to write return false, err m aane k baad return hoga false??
    //next we call wapis bhi aati h??
    //where to return false..in catch or try..
    //where we should return false message, if not removed the friends or user..??
  },
  /*
  addUser(args, req){
    
      const name=args.userInput.name;
  }
      */
};
