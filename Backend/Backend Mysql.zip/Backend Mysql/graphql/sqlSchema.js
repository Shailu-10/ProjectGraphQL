const { buildSchema } = require("graphql");
//return type of hello is string
// ! means required
//Rootquery will contain functions that telling return type
//input is the input we expect from frontend
/*

simple type user{
    //is used to define user or anything else
}
    type query{
    //will define function to execute and what they will return
    ex: createUser(inputfor:inputforcreateuser): User
    //createUser is the function to be executed for fetching data
    //and input passed will be input for create user and it will return user
    
    }
    type mutation{

    }
    here we defining schema, then we have to make resolvers for them

    //query return 
*/
module.exports = buildSchema(`
    type userSchema{
        name:String!
        friends:[String]
    }
    input forCreatingUser{
        name:String!
        password:String!
    }
    type AuthData {
        success: Boolean!
        token: String
        message: String
    }
    type friendsArray{
        friends:[String],
        message:String,
        success:Boolean
    }
    type Mutation{
        createUser(username:String,password:String) : AuthData!
        loginUser(username:String,password:String) : AuthData!
        mutualFriends(curr_user_id:String!,friend_user_id:String!):friendsArray
        showFriends(curr_user_id:String!): [String]
        addFriend(curr_user_id:String!,friend_user_id:String!): String
        deleteUser(curr_user_id:String!):String
        deleteFriend(curr_user_id:String!,friend_user_id:String!):String
        allPendingRequestSendByUser(username:String!):friendsArray
        incomingRequests(username:String!):friendsArray
        addToFriends(username:String!,friendsUsername:String!):Boolean
        delelteFromPendingRequests(username:String!,friendsUsername:String!):Boolean
        handleWithdrawRequest(sender:String!,reciever:String!):Boolean
    }
    type RootQuery{
        showAllUsers:[String]
        showAllFriends(username:String!):friendsArray
        userDetail(curr_user_id:String!):userSchema
    }
    schema{
        query: RootQuery
        mutation: Mutation   
    }
    `);
//query doesn't take any paramerters
/*
        type Query {
        getUsers: [User!]!
        }

        type User {
        id: ID!
        name: String!
        email: String!
        }
    */
