const jwt = require("jsonwebtoken");
require("dotenv").config();

const SECRET_KEY = "secretsuperstar";

exports.verifyToken = (req, res, next) => {
  const authHeader = req.get("Authorization");
  if (!authHeader) {
    req.isAuth = false;
    return next();
  }

  const token = authHeader.split(" ")[1]; // "Bearer <token>"
  console.log("bearer token: " + token);
  if (!token || token === "") {
    console.log("req failing bcz token empty");
    req.isAuth = false;
    return next();
  }

  let decodedToken;
  try {
    console.log("request failing because can't verify");
    decodedToken = jwt.verify(token, SECRET_KEY);
  } catch (err) {
    console.log("request failing at catch");
    req.isAuth = false;
    return next();
  }

  if (!decodedToken) {
    console.log("decoded token different");
    req.isAuth = false;
    return next();
  }

  req.isAuth = true;
  console.log("decoded token" + decodedToken.username);
  req.userId = decodedToken.username;
  next();
};
